//package com.example.cristian.journalapp;
//TODO fix the layout to use a custom layout
//import android.widget.ImageButton;
//
//public class CustomList {
//    private String entry;
//
//    private ImageButton edit;
//
//    private ImageButton delete;
//
//    public CustomList(String ventry, ImageButton vedit, ImageButton vdelete)
//    {
//        edit = vedit;
//        entry = ventry;
//        delete = vdelete;
//    }
//
//    /**
//     * Get the name of the Android version
//     */
//    public String getEntry() {
//
//        return entry;
//    }
//
//    /**
//     * Get the Android version number
//     */
//    public ImageButton getEdit() {
//        return edit;
//    }
//
//    /**
//     * Get the image resource ID
//     */
//    public ImageButton getDelete() {
//        return delete;
//    }
//
//
//}
//
