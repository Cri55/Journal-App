package com.example.cristian.journalapp;

class SignInTest {
}
